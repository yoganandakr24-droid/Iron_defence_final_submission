import pytest
from app.risk_engine.evidence_fusion import EvidenceFusionEngine
from app.risk_engine.risk_calculator import RiskEngine
from app.services.attack_story_service import AttackStoryService
from app.intelligence.mitre import MITREMapper

def test_evidence_deduplication():
    fusion = EvidenceFusionEngine()
    se_result = {
        "credential_request": {"detected": True, "score": 0.95},
        "urgency": {"detected": True, "score": 0.8}
    }
    fused_1 = fusion.fuse(
        nlp_result={"classification": "PHISHING", "score_type": "heuristic", "model": "mock"},
        se_result=se_result,
        url_result={},
        threat_intel_result={},
        qr_result={},
        ocr_result={}
    )
    # Re-running fusion should deduplicate signal keys
    signals = [e["signal"] for e in fused_1]
    assert len(signals) == len(set(signals))

def test_risk_calculation_bounds():
    risk_engine = RiskEngine()
    mock_evidence = [
        {"category": "NLP", "signal": "NLP_PHISHING_INTENT", "score": 30.0, "confidence": 0.9},
        {"category": "THREAT_INTELLIGENCE", "signal": "MALICIOUS_REPUTATION", "score": 30.0, "confidence": 0.95},
        {"category": "URL", "signal": "SUSPICIOUS_URL_PATTERN", "score": 25.0, "confidence": 0.88},
        {"category": "SOCIAL_ENGINEERING", "signal": "CREDENTIAL_REQUEST", "score": 10.0, "confidence": 0.9}
    ]
    res = risk_engine.calculate_risk(mock_evidence)
    assert res["risk_score"] <= 100.0
    assert res["risk_level"] in ["CRITICAL", "HIGH"]
    assert res["classification"] == "PHISHING"
    assert len(res["score_breakdown"]) > 0

def test_attacker_objective_classification():
    story_service = AttackStoryService()
    ev = [{"signal": "CREDENTIAL_REQUEST"}]
    obj = story_service.determine_attacker_objective(ev, {})
    assert obj["objective"] == "CREDENTIAL_THEFT"

def test_mitre_mapping():
    mapper = MITREMapper()
    ev = [{"category": "SOCIAL_ENGINEERING", "signal": "CREDENTIAL_REQUEST"}]
    mapped = mapper.map_evidence(ev)
    assert len(mapped) > 0
    assert mapped[0]["technique_id"] == "T1566.002"
