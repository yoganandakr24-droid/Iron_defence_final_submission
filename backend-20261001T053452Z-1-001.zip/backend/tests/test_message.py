import pytest
from app.analyzers.social_engineering import SocialEngineeringAnalyzer
from app.analyzers.nlp_analyzer import MockNLPProvider

def test_urgency_detection():
    analyzer = SocialEngineeringAnalyzer()
    res = analyzer.analyze("URGENT! Your university account will be suspended today unless action is taken.")
    assert res["urgency"]["detected"] is True
    assert res["urgency"]["score"] > 0

def test_credential_request_detection():
    analyzer = SocialEngineeringAnalyzer()
    res = analyzer.analyze("Verify your password immediately to unlock your student profile.")
    assert res["credential_request"]["detected"] is True
    assert res["credential_request"]["score"] > 0

def test_financial_request_detection():
    analyzer = SocialEngineeringAnalyzer()
    res = analyzer.analyze("Congratulations! Pay ₹999 immediately via UPI to confirm your seat.")
    assert res["financial_request"]["detected"] is True
    assert res["financial_request"]["score"] > 0

def test_phishing_message_nlp():
    nlp = MockNLPProvider()
    res = nlp.analyze("URGENT! Verify your password at http://phishing.example to avoid deactivation.")
    assert res.classification == "PHISHING"
    assert res.heuristic_score >= 50.0

def test_benign_message_nlp():
    nlp = MockNLPProvider()
    res = nlp.analyze("The university library will remain open until 8 PM today.")
    assert res.classification == "BENIGN"
    assert res.heuristic_score < 35.0
