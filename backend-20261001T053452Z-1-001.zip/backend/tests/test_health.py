import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "iron-defense-backend"
    assert "providers" in data
    assert "nlp" in data["providers"]
    assert "threat_intelligence" in data["providers"]
