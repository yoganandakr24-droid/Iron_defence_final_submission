import pytest
from app.analyzers.url_analyzer import URLAnalyzer
from app.utils.url_utils import parse_url_details

def test_suspicious_url():
    analyzer = URLAnalyzer()
    res = analyzer.analyze_urls("Check http://student-account-verification.example/login")
    assert res["count"] > 0
    assert res["max_risk_score"] > 20.0
    primary = res["primary_url"]
    assert "login" in primary["details"]["matched_suspicious_keywords"]

def test_legitimate_url():
    analyzer = URLAnalyzer()
    res = analyzer.analyze_urls("https://studentportal.univ.edu/timetable")
    assert res["count"] > 0
    assert res["max_risk_score"] < 25.0

def test_ip_address_url():
    analyzer = URLAnalyzer()
    res = analyzer.analyze_urls("http://192.168.1.100/login")
    assert res["count"] > 0
    primary = res["primary_url"]
    assert primary["is_ip_address"] is True
    assert primary["risk_score"] >= 35.0

def test_shortened_and_punycode_url():
    details = parse_url_details("https://bit.ly/3xYz123")
    assert details["is_shortened"] is True

    details_puny = parse_url_details("https://xn--appl-4ca.com")
    assert details_puny["is_punycode"] is True
