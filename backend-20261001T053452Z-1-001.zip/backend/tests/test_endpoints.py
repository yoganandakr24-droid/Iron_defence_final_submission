import io
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_complete_unified_analyze():
    payload = {
        "text": "URGENT! Your university account will be suspended today. Verify your password immediately at https://student-account-verification.example/login",
        "url": "https://student-account-verification.example/login",
        "source": "sms"
    }
    response = client.post("/api/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "analysis_id" in data
    assert data["classification"] == "PHISHING"
    assert data["risk_level"] in ["CRITICAL", "HIGH"]
    assert data["risk_score"] >= 70
    assert len(data["evidence"]) > 0
    assert "attacker_objective" in data
    assert "mitre_attack" in data
    assert "attack_story" in data
    assert "safe_actions" in data

def test_benign_unified_analyze():
    payload = {
        "text": "Placement training will be held tomorrow at 2 PM in Block A.",
        "source": "email"
    }
    response = client.post("/api/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["risk_level"] in ["LOW", "MEDIUM"]

def test_invalid_upload():
    # Attempt uploading an invalid file extension (e.g. .txt instead of image)
    file_content = b"This is invalid text file"
    response = client.post(
        "/api/analyze/image",
        files={"file": ("malicious.txt", io.BytesIO(file_content), "text/plain")}
    )
    assert response.status_code == 400
    assert "error" in response.json()

def test_history_workflow():
    # Run analysis first
    payload = {"text": "Test message for history check", "source": "test"}
    resp = client.post("/api/analyze", json=payload)
    an_id = resp.json()["analysis_id"]

    # Retrieve history
    hist_resp = client.get("/api/history")
    assert hist_resp.status_code == 200
    hist_data = hist_resp.json()
    assert len(hist_data) > 0
    assert any(item["analysis_id"] == an_id for item in hist_data)

    # Get specific analysis by ID
    get_resp = client.get(f"/api/analysis/{an_id}")
    assert get_resp.status_code == 200
    assert get_resp.json()["analysis_id"] == an_id

    # Delete record
    del_resp = client.delete(f"/api/history/{an_id}")
    assert del_resp.status_code == 200
