from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.schemas.evidence import EvidenceItem, ScoreBreakdownItem

class AnalysisRequest(BaseModel):
    text: Optional[str] = None
    url: Optional[str] = None
    source: Optional[str] = "manual"

class MessageAnalysisRequest(BaseModel):
    text: str
    source: Optional[str] = "sms"

class UrlAnalysisRequest(BaseModel):
    url: str
    source: Optional[str] = "browser"

class SocialEngineeringResult(BaseModel):
    urgency: Dict[str, Any] = Field(default_factory=dict)
    fear: Dict[str, Any] = Field(default_factory=dict)
    authority: Dict[str, Any] = Field(default_factory=dict)
    reward: Dict[str, Any] = Field(default_factory=dict)
    scarcity: Dict[str, Any] = Field(default_factory=dict)
    impersonation: Dict[str, Any] = Field(default_factory=dict)
    credential_request: Dict[str, Any] = Field(default_factory=dict)
    financial_request: Dict[str, Any] = Field(default_factory=dict)
    call_to_action: Dict[str, Any] = Field(default_factory=dict)
    suspicious_attachment: Dict[str, Any] = Field(default_factory=dict)
    suspicious_link: Dict[str, Any] = Field(default_factory=dict)

class AttackerObjectiveResult(BaseModel):
    objective: str
    confidence: float
    score_type: str = "heuristic"
    evidence: List[str] = Field(default_factory=list)

class AttackStoryResult(BaseModel):
    entry_vector: str
    social_engineering: str
    user_action: str
    attacker_objective: str
    potential_impact: str

class AnalysisResponse(BaseModel):
    analysis_id: str
    timestamp: str
    classification: str
    risk_score: float
    risk_level: str
    confidence: float
    summary: str
    evidence: List[EvidenceItem] = Field(default_factory=list)
    score_breakdown: List[ScoreBreakdownItem] = Field(default_factory=list)
    social_engineering: Dict[str, Any] = Field(default_factory=dict)
    url_analysis: Dict[str, Any] = Field(default_factory=dict)
    threat_intelligence: Dict[str, Any] = Field(default_factory=dict)
    attacker_objective: Dict[str, Any] = Field(default_factory=dict)
    mitre_attack: List[Dict[str, Any]] = Field(default_factory=list)
    attack_story: Dict[str, Any] = Field(default_factory=dict)
    safe_actions: List[str] = Field(default_factory=list)
    processing: Dict[str, Any] = Field(default_factory=dict)
