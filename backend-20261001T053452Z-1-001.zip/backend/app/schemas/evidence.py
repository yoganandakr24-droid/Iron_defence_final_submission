from pydantic import BaseModel, Field
from typing import Optional, Literal

SeverityLevel = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
EvidenceCategory = Literal[
    "NLP", "URL", "THREAT_INTELLIGENCE", "SOCIAL_ENGINEERING", "QR", "OCR", "REPUTATION"
]

class EvidenceItem(BaseModel):
    id: str
    category: EvidenceCategory
    signal: str
    description: str
    severity: SeverityLevel
    score: float = Field(..., ge=0, le=100)
    confidence: float = Field(..., ge=0.0, le=1.0)
    source: str = "rule"

class ScoreBreakdownItem(BaseModel):
    signal: str
    contribution: float
