from pydantic import BaseModel
from typing import Optional, Any, Dict

class ErrorDetail(BaseModel):
    code: str
    message: str

class ErrorResponse(BaseModel):
    error: ErrorDetail

class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    providers: Dict[str, Any]
