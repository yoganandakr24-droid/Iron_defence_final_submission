import os
import re
import uuid
from typing import Tuple
from fastapi import HTTPException, status, UploadFile
from app.core.config import settings

ALLOWED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
ALLOWED_MIME_TYPES = {"image/png", "image/jpeg", "image/jpg", "image/webp"}
MAX_FILE_BYTES = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
MAX_TEXT_LENGTH = 100000

def validate_image_file(file: UploadFile) -> Tuple[str, str]:
    """
    Validates uploaded image file size, extension, and mime type.
    Returns (safe_filename, file_extension).
    """
    filename = file.filename or "upload.png"
    ext = os.path.splitext(filename)[1].lower()
    
    # Path traversal check
    safe_basename = os.path.basename(filename)
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "INVALID_FILENAME", "message": "Potentially unsafe file name detected."}}
        )

    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "INVALID_FILE_TYPE", "message": f"Unsupported file extension '{ext}'. Allowed: {ALLOWED_IMAGE_EXTENSIONS}"}}
        )

    if file.content_type and file.content_type.lower() not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "INVALID_MIME_TYPE", "message": f"Unsupported MIME type '{file.content_type}'."}}
        )

    unique_filename = f"{uuid.uuid4().hex}{ext}"
    return unique_filename, ext

def validate_text_length(text: str, max_len: int = MAX_TEXT_LENGTH) -> str:
    if len(text) > max_len:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "TEXT_TOO_LONG", "message": f"Input text exceeds maximum allowed length of {max_len} characters."}}
        )
    return text.strip()
