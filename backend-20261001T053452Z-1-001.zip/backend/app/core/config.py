import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    APP_NAME: str = "Iron Defense"
    APP_ENV: str = "development"
    DATABASE_URL: str = "sqlite:///./iron_defense.db"

    LLM_PROVIDER: str = "ollama"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3.5:9b"
    LLM_API_KEY: Optional[str] = ""
    LLM_MODEL: Optional[str] = ""

    THREAT_INTEL_PROVIDER: str = "mock"
    THREAT_INTEL_API_KEY: Optional[str] = ""

    DEBERTA_MODEL_PATH: Optional[str] = ""

    MAX_UPLOAD_SIZE_MB: int = 10
    DEMO_MODE: bool = True

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = Settings()
