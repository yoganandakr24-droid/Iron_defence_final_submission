import logging
import sys
from app.core.config import settings

def setup_logging():
    log_level = logging.DEBUG if settings.APP_ENV == "development" else logging.INFO
    
    logger = logging.getLogger("iron_defense")
    logger.setLevel(log_level)
    
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            '[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
    return logger

logger = setup_logging()
