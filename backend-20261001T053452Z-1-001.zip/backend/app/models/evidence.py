# Evidence model definitions for database persistence
from typing import Dict, Any

def format_evidence_record(evidence_item: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": evidence_item.get("id"),
        "category": evidence_item.get("category"),
        "signal": evidence_item.get("signal"),
        "description": evidence_item.get("description"),
        "severity": evidence_item.get("severity"),
        "score": evidence_item.get("score"),
        "confidence": evidence_item.get("confidence"),
        "source": evidence_item.get("source", "rule")
    }
