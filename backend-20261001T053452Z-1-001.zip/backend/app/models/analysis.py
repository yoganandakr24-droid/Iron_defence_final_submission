from sqlalchemy import Column, String, Float, DateTime, JSON, Text
from datetime import datetime
from app.models.database import Base

class AnalysisRecord(Base):
    __tablename__ = "analysis_records"

    analysis_id = Column(String(36), primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    source = Column(String(50), nullable=True)
    input_type = Column(String(50), nullable=True)
    original_text = Column(Text, nullable=True)
    urls = Column(JSON, nullable=True)
    classification = Column(String(50))
    risk_score = Column(Float)
    risk_level = Column(String(50))
    confidence = Column(Float)
    attacker_objective = Column(JSON, nullable=True)
    attack_story = Column(JSON, nullable=True)
    evidence = Column(JSON, nullable=True)
    mitre_mapping = Column(JSON, nullable=True)
    safe_actions = Column(JSON, nullable=True)
    full_response = Column(JSON, nullable=True)
