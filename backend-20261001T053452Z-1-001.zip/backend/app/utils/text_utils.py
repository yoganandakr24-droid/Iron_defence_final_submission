import re
from typing import List, Dict, Set

def normalize_text(text: str) -> str:
    if not text:
        return ""
    # Normalize whitespace, strip control characters
    text = re.sub(r'[\r\n\t]+', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

# Multilingual keywords dictionary (English, Hindi, Kannada)
MULTILINGUAL_KEYWORDS = {
    "urgency": {
        "en": ["urgent", "immediately", "today only", "suspension", "suspend", "24 hours", "account blocked", "deactivate", "expire", "action required", "last chance", "hurry"],
        "hi": ["तुरंत", "निलंबित", "कार्रवाई आवश्यक", "अंतिम अवसर"],
        "kn": ["ತಕ್ಷಣ", "ಅಮಾನತು", "ಕೊನೆಯ ಅವಕಾಶ"]
    },
    "credential_request": {
        "en": ["password", "verify your account", "verify password", "login", "credentials", "security update", "enter password", "reset password", "passcode"],
        "hi": ["पासवर्ड", "लॉगिन करें", "खाता सत्यापित करें", "पासवर्ड दर्ज करें"],
        "kn": ["ಪಾಸ್ವರ್ಡ್", "ಲಾಗಿನ್ ಮಾಡಿ", "ಖಾತೆ ಪರಿಶೀಲಿಸಿ"]
    },
    "financial_request": {
        "en": ["pay", "payment", "bank details", "otp", "upi", "credit card", "fee", "transfer", "refund", "₹", "rs", "money"],
        "hi": ["भुगतान", "बैंक खाता", "ओटीपी", "पैसे", "फीस", "रुपये"],
        "kn": ["ಪಾವತಿ", "ಬ್ಯಾಂಕ್ ವಿವರ", "ಒಟಿಪಿ", "ಹಣ", "ಶುಲ್ಕ"]
    },
    "reward": {
        "en": ["congratulations", "selected", "scholarship", "approved", "won", "stipend", "bonus", "cashback", "free gift"],
        "hi": ["बधाई", "छात्रवृत्ति", "स्वीकृत", "जीता", "पुरस्कार"],
        "kn": ["ಅಭಿನಂದನೆಗಳು", "ಶಿಷ್ಯವೇತನ", "ಆಯ್ಕೆಯಾಗಿದ್ದೀರಿ", "ಗೆದ್ದಿದ್ದೀರಿ"]
    },
    "authority": {
        "en": ["university", "college", "administration", "dean", "placement cell", "bank", "official", "department", "govt", "police"],
        "hi": ["विश्वविद्यालय", "कॉलेज", "प्रशासन", "बैंक", "आधिकारिक"],
        "kn": ["ವಿಶ್ವವಿದ್ಯಾಲಯ", "ಕಾಲೇಜು", "ಆಡಳಿತ", "ಬ್ಯಾಂಕ್", "ಅಧಿಕೃತ"]
    }
}

def match_multilingual_signals(text: str, category: str) -> Dict[str, Any]:
    text_lower = text.lower()
    matched = []
    category_data = MULTILINGUAL_KEYWORDS.get(category, {})
    for lang, keywords in category_data.items():
        for kw in keywords:
            if kw.lower() in text_lower:
                matched.append({"keyword": kw, "language": lang})
    
    return {
        "detected": len(matched) > 0,
        "count": len(matched),
        "matches": matched
    }
