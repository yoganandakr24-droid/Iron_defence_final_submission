import re
import urllib.parse
import ipaddress
import tldextract
from typing import List, Dict, Any, Optional

SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "is.gd", "buff.ly", "ow.ly",
    "rebrand.ly", "cutt.ly", "goo.gl", "tiny.cc", "shorturl.at"
}

SUSPICIOUS_TLDS = {
    "xyz", "top", "click", "download", "link", "info", "tk", "ml",
    "ga", "cf", "gq", "club", "site", "online", "live", "vip"
}

SUSPICIOUS_KEYWORDS = [
    "login", "verify", "secure", "account", "update", "bank", "portal",
    "confirm", "password", "credential", "scholarship", "internship",
    "payment", "fee", "kyc", "claim", "free", "award", "urgent"
]

URL_REGEX = re.compile(
    r'(?:(?:https?|ftp):\/\/)?'  # scheme
    r'(?:[^\s:@]+(?::[^\s:@]*)?@)?'  # user:pass
    r'(?:'
    r'(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}'  # domain
    r'|'
    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'  # IPv4
    r')'
    r'(?::\d+)?'  # port
    r'(?:[\/?#]\S*)?',  # path & query
    re.IGNORECASE
)

def extract_urls(text: str) -> List[str]:
    if not text:
        return []
    matches = URL_REGEX.findall(text)
    cleaned_urls = []
    for m in matches:
        m_str = m.strip(".,;:()'\"<>")
        if len(m_str) > 4 and ("." in m_str or ":" in m_str):
            if not m_str.startswith(("http://", "https://", "ftp://")):
                m_str = "https://" + m_str
            cleaned_urls.append(m_str)
    return list(dict.fromkeys(cleaned_urls))

def parse_url_details(url: str) -> Dict[str, Any]:
    if not url.startswith(("http://", "https://", "ftp://")):
        url = "https://" + url

    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return {
            "valid": False,
            "raw_url": url,
            "error": "Failed to parse URL"
        }

    hostname = parsed.hostname or ""
    
    # Check IP address
    is_ip = False
    try:
        if hostname:
            ipaddress.ip_address(hostname)
            is_ip = True
    except ValueError:
        is_ip = False

    # Check Punycode
    is_punycode = hostname.startswith("xn--") or ".xn--" in hostname

    # Extract domain info with tldextract
    ext = tldextract.extract(url)
    domain = ext.domain
    subdomain = ext.subdomain
    suffix = ext.suffix
    registered_domain = getattr(ext, "top_domain_under_public_suffix", ext.registered_domain)

    subdomain_count = len(subdomain.split(".")) if subdomain else 0
    is_shortened = registered_domain.lower() in SHORTENER_DOMAINS or hostname.lower() in SHORTENER_DOMAINS
    is_suspicious_tld = suffix.lower() in SUSPICIOUS_TLDS

    # Check for @ symbol in URL
    has_at_symbol = "@" in url

    # Hex/URL encoding in path
    has_hex_encoding = "%" in parsed.path or "%" in parsed.query

    # Suspicious port
    has_suspicious_port = parsed.port not in [None, 80, 443]

    # Keyword check
    url_lower = url.lower()
    matched_keywords = [kw for kw in SUSPICIOUS_KEYWORDS if kw in url_lower]

    return {
        "valid": True,
        "url": url,
        "scheme": parsed.scheme,
        "is_https": parsed.scheme.lower() == "https",
        "hostname": hostname,
        "domain": domain,
        "registered_domain": registered_domain,
        "subdomain": subdomain,
        "tld": suffix,
        "url_length": len(url),
        "hostname_length": len(hostname),
        "path_length": len(parsed.path),
        "number_of_subdomains": subdomain_count,
        "is_ip_address": is_ip,
        "is_punycode": is_punycode,
        "is_shortened": is_shortened,
        "has_at_symbol": has_at_symbol,
        "is_suspicious_tld": is_suspicious_tld,
        "has_hex_encoding": has_hex_encoding,
        "has_suspicious_port": has_suspicious_port,
        "matched_suspicious_keywords": matched_keywords
    }
