import re
from typing import Optional

def sanitize_string(text: Optional[str]) -> str:
    if not text:
        return ""
    # Strip dangerous control chars
    return re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text).strip()

def is_valid_http_url(url: str) -> bool:
    if not url:
        return False
    return bool(re.match(r'^https?://[^\s/$.?#].[^\s]*$', url, re.IGNORECASE))
