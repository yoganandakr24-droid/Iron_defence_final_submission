import json
import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.models.analysis import AnalysisRecord
from app.schemas.analysis import (
    AnalysisRequest, MessageAnalysisRequest, UrlAnalysisRequest, AnalysisResponse
)
from app.services.analysis_service import AnalysisService
from app.core.security import validate_image_file, validate_text_length
from app.core.config import settings

router = APIRouter(prefix="/api", tags=["Analysis"])
analysis_service = AnalysisService()

DEMO_CASES_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "demo_cases.json")

@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_unified(request: AnalysisRequest, db: Session = Depends(get_db)):
    if not request.text and not request.url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "MISSING_INPUT", "message": "Either 'text' or 'url' must be provided for analysis."}}
        )

    text_clean = validate_text_length(request.text) if request.text else None
    
    result = await analysis_service.run_unified_analysis(
        db=db,
        text=text_clean,
        url=request.url,
        source=request.source or "manual",
        input_type="unified"
    )
    return result

@router.post("/analyze/message", response_model=AnalysisResponse)
async def analyze_message(request: MessageAnalysisRequest, db: Session = Depends(get_db)):
    text_clean = validate_text_length(request.text)
    result = await analysis_service.run_unified_analysis(
        db=db,
        text=text_clean,
        source=request.source or "sms",
        input_type="message"
    )
    return result

@router.post("/analyze/url", response_model=AnalysisResponse)
async def analyze_url(request: UrlAnalysisRequest, db: Session = Depends(get_db)):
    if not request.url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "MISSING_URL", "message": "URL parameter is required."}}
        )
    result = await analysis_service.run_unified_analysis(
        db=db,
        url=request.url,
        source=request.source or "browser",
        input_type="url"
    )
    return result

@router.post("/analyze/qr", response_model=AnalysisResponse)
async def analyze_qr(
    file: UploadFile = File(...),
    source: str = Form("qr"),
    db: Session = Depends(get_db)
):
    _, _ = validate_image_file(file)
    contents = await file.read()
    if len(contents) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "FILE_TOO_LARGE", "message": "File exceeds maximum size limit."}}
        )

    result = await analysis_service.run_unified_analysis(
        db=db,
        image_bytes=contents,
        source=source,
        input_type="qr"
    )
    return result

@router.post("/analyze/image", response_model=AnalysisResponse)
async def analyze_image(
    file: UploadFile = File(...),
    source: str = Form("screenshot"),
    db: Session = Depends(get_db)
):
    _, _ = validate_image_file(file)
    contents = await file.read()
    if len(contents) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": {"code": "FILE_TOO_LARGE", "message": "File exceeds maximum size limit."}}
        )

    result = await analysis_service.run_unified_analysis(
        db=db,
        image_bytes=contents,
        source=source,
        input_type="image"
    )
    return result

@router.get("/analysis/{analysis_id}", response_model=AnalysisResponse)
async def get_analysis(analysis_id: str, db: Session = Depends(get_db)):
    record = db.query(AnalysisRecord).filter(AnalysisRecord.analysis_id == analysis_id).first()
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "NOT_FOUND", "message": f"Analysis record with ID '{analysis_id}' not found."}}
        )
    return record.full_response

@router.get("/demo/cases")
async def get_demo_cases():
    abs_path = os.path.abspath(DEMO_CASES_PATH)
    if os.path.exists(abs_path):
        with open(abs_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

@router.get("/demo/cases/{case_id}")
async def get_demo_case_by_id(case_id: str):
    abs_path = os.path.abspath(DEMO_CASES_PATH)
    if os.path.exists(abs_path):
        with open(abs_path, "r", encoding="utf-8") as f:
            cases = json.load(f)
            for c in cases:
                if c.get("id") == case_id:
                    return c
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={"error": {"code": "NOT_FOUND", "message": f"Demo case '{case_id}' not found."}}
    )
