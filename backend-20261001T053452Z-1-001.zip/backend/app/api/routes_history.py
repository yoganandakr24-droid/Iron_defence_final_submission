from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.models.analysis import AnalysisRecord
from app.schemas.analysis import AnalysisResponse

router = APIRouter(prefix="/api", tags=["History"])

@router.get("/history", response_model=List[AnalysisResponse])
async def get_history(
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    records = (
        db.query(AnalysisRecord)
        .order_by(AnalysisRecord.timestamp.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return [r.full_response for r in records if r.full_response]

@router.delete("/history/{analysis_id}")
async def delete_history_item(analysis_id: str, db: Session = Depends(get_db)):
    record = db.query(AnalysisRecord).filter(AnalysisRecord.analysis_id == analysis_id).first()
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": {"code": "NOT_FOUND", "message": f"Analysis record '{analysis_id}' not found."}}
        )
    db.delete(record)
    db.commit()
    return {"status": "success", "message": f"Analysis record '{analysis_id}' deleted."}
