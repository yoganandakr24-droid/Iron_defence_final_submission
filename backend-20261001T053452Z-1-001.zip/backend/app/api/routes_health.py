import httpx
from fastapi import APIRouter
from app.core.config import settings

router = APIRouter(tags=["Health"])

@router.get("/api/health")
async def health_check():
    # Check Ollama availability if configured
    ollama_available = False
    if settings.LLM_PROVIDER in ["ollama", "local"]:
        try:
            async with httpx.AsyncClient(timeout=1.0) as client:
                r = await client.get(f"{settings.OLLAMA_BASE_URL.rstrip('/')}/api/tags")
                if r.status_code == 200:
                    ollama_available = True
        except Exception:
            ollama_available = False

    return {
        "status": "healthy",
        "service": "iron-defense-backend",
        "version": "1.0.0",
        "providers": {
            "nlp": {
                "provider": settings.LLM_PROVIDER,
                "model": settings.OLLAMA_MODEL if settings.LLM_PROVIDER == "ollama" else "heuristic",
                "available": ollama_available if settings.LLM_PROVIDER == "ollama" else True
            },
            "threat_intelligence": settings.THREAT_INTEL_PROVIDER,
            "ocr": "available",
            "qr": "available"
        }
    }
