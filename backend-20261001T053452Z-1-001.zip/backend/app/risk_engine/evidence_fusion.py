from typing import List, Dict, Any

class EvidenceFusionEngine:
    """
    Fuses findings from NLP, Social Engineering rules, URL analyzer,
    Threat Intelligence, QR, and OCR into a deduplicated evidence set.
    """

    def fuse(
        self,
        nlp_result: Dict[str, Any],
        se_result: Dict[str, Any],
        url_result: Dict[str, Any],
        threat_intel_result: Dict[str, Any],
        qr_result: Dict[str, Any],
        ocr_result: Dict[str, Any]
    ) -> List[Dict[str, Any]]:

        evidence_items = []
        ev_counter = 1
        seen_signals = set()

        def add_ev(category: str, signal: str, desc: str, severity: str, score: float, confidence: float, source: str = "rule"):
            nonlocal ev_counter
            sig_key = f"{category}:{signal}"
            if sig_key in seen_signals:
                return
            seen_signals.add(sig_key)
            
            ev_id = f"EV{ev_counter:03d}"
            ev_counter += 1
            evidence_items.append({
                "id": ev_id,
                "category": category,
                "signal": signal,
                "description": desc,
                "severity": severity,
                "score": score,
                "confidence": confidence,
                "source": source
            })

        # 1. Social Engineering Signals
        if se_result:
            for sig, data in se_result.items():
                if data.get("detected"):
                    score = round(data.get("score", 0.5) * 20, 2)
                    severity = "CRITICAL" if sig in ["credential_request", "financial_request"] else ("HIGH" if sig in ["urgency", "impersonation", "fear"] else "MEDIUM")
                    add_ev(
                        category="SOCIAL_ENGINEERING",
                        signal=sig.upper(),
                        desc=f"Detected social engineering pattern: {sig.replace('_', ' ')}",
                        severity=severity,
                        score=score,
                        confidence=0.90,
                        source="heuristic_rule"
                    )

        # 2. NLP Analyzer Result
        if nlp_result:
            classification = nlp_result.get("classification")
            score_type = nlp_result.get("score_type", "heuristic")
            model = nlp_result.get("model", "nlp")
            
            if classification == "PHISHING":
                prob = nlp_result.get("phishing_probability")
                score = round((prob * 30) if prob is not None else 25.0, 2)
                add_ev(
                    category="NLP",
                    signal="NLP_PHISHING_INTENT",
                    desc=f"NLP engine ({model}) classified intent as PHISHING ({score_type})",
                    severity="HIGH",
                    score=score,
                    confidence=prob if prob is not None else 0.85,
                    source=f"nlp_{score_type}"
                )
            elif classification == "SUSPICIOUS":
                add_ev(
                    category="NLP",
                    signal="NLP_SUSPICIOUS_INTENT",
                    desc=f"NLP engine ({model}) classified text as SUSPICIOUS",
                    severity="MEDIUM",
                    score=15.0,
                    confidence=0.75,
                    source=f"nlp_{score_type}"
                )

        # 3. URL Analyzer Results
        if url_result and url_result.get("count", 0) > 0:
            max_url_risk = url_result.get("max_risk_score", 0.0)
            primary = url_result.get("primary_url")
            if primary:
                patterns = primary.get("suspicious_patterns", [])
                for pat in patterns:
                    add_ev(
                        category="URL",
                        signal="SUSPICIOUS_URL_PATTERN",
                        desc=f"URL signal: {pat}",
                        severity="HIGH" if "IP address" in pat or "Userinfo" in pat else "MEDIUM",
                        score=min(25.0, round(max_url_risk * 0.25, 2)),
                        confidence=0.88,
                        source="url_analyzer"
                    )

        # 4. Threat Intelligence Results
        if threat_intel_result and threat_intel_result.get("available"):
            rep = threat_intel_result.get("reputation")
            source_lbl = threat_intel_result.get("source", "threat_intel")
            if rep == "malicious":
                add_ev(
                    category="THREAT_INTELLIGENCE",
                    signal="MALICIOUS_REPUTATION",
                    desc=f"Domain has known malicious reputation ({source_lbl})",
                    severity="CRITICAL",
                    score=30.0,
                    confidence=0.98,
                    source="threat_intel"
                )
            elif rep == "suspicious":
                add_ev(
                    category="THREAT_INTELLIGENCE",
                    signal="SUSPICIOUS_REPUTATION",
                    desc=f"Domain flagged as suspicious in threat intelligence ({source_lbl})",
                    severity="HIGH",
                    score=18.0,
                    confidence=0.85,
                    source="threat_intel"
                )

        # 5. QR Analyzer Results
        if qr_result and qr_result.get("qr_detected"):
            add_ev(
                category="QR",
                signal="QR_CODE_EMBEDDED",
                desc=f"Message contains QR code directing to: {qr_result.get('decoded_content')}",
                severity="MEDIUM",
                score=10.0,
                confidence=0.95,
                source="qr_decoder"
            )

        # 6. OCR Analyzer Results
        if ocr_result and ocr_result.get("has_text"):
            add_ev(
                category="OCR",
                signal="OCR_TEXT_EXTRACTED",
                desc="Extracted textual content from uploaded image",
                severity="LOW",
                score=0.0,
                confidence=ocr_result.get("confidence", 0.85),
                source="ocr_engine"
            )

        return evidence_items
