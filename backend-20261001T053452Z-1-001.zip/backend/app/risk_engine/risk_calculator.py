from typing import List, Dict, Any, Tuple
from app.risk_engine.rules import RULE_CONTRIBUTIONS, DEFAULT_THRESHOLDS

class RiskEngine:
    """
    Transparent evidence-fusion risk calculator.
    Produces risk score (0-100), risk level (LOW, MEDIUM, HIGH, CRITICAL),
    classification, confidence, and detailed score breakdown.
    """

    def calculate_risk(self, evidence_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        base_score = 0.0
        breakdown = []
        category_scores = {
            "NLP": 0.0,
            "URL": 0.0,
            "THREAT_INTELLIGENCE": 0.0,
            "SOCIAL_ENGINEERING": 0.0,
            "QR": 0.0,
            "OCR": 0.0
        }

        for ev in evidence_items:
            sig = ev.get("signal")
            cat = ev.get("category", "OTHER")
            ev_score = ev.get("score", 0.0)

            # Cap individual contributions per category to prevent over-stacking
            contribution = RULE_CONTRIBUTIONS.get(sig, min(15.0, ev_score))

            if cat == "NLP":
                capped_contrib = min(30.0 - category_scores["NLP"], contribution)
                category_scores["NLP"] += max(0.0, capped_contrib)
                breakdown.append({"signal": sig.lower(), "contribution": round(max(0.0, capped_contrib), 2)})

            elif cat == "URL":
                capped_contrib = min(25.0 - category_scores["URL"], contribution)
                category_scores["URL"] += max(0.0, capped_contrib)
                breakdown.append({"signal": sig.lower(), "contribution": round(max(0.0, capped_contrib), 2)})

            elif cat == "THREAT_INTELLIGENCE":
                capped_contrib = min(30.0 - category_scores["THREAT_INTELLIGENCE"], contribution)
                category_scores["THREAT_INTELLIGENCE"] += max(0.0, capped_contrib)
                breakdown.append({"signal": sig.lower(), "contribution": round(max(0.0, capped_contrib), 2)})

            elif cat == "SOCIAL_ENGINEERING":
                capped_contrib = min(20.0 - category_scores["SOCIAL_ENGINEERING"], contribution)
                category_scores["SOCIAL_ENGINEERING"] += max(0.0, capped_contrib)
                breakdown.append({"signal": sig.lower(), "contribution": round(max(0.0, capped_contrib), 2)})

            elif cat == "QR":
                capped_contrib = min(15.0 - category_scores["QR"], contribution)
                category_scores["QR"] += max(0.0, capped_contrib)
                breakdown.append({"signal": sig.lower(), "contribution": round(max(0.0, capped_contrib), 2)})

        total_score = sum(category_scores.values())

        # Cap total risk score at 100
        final_risk_score = round(min(100.0, total_score), 2)

        # Determine Risk Level
        if final_risk_score >= 75:
            risk_level = "CRITICAL"
            classification = "PHISHING"
        elif final_risk_score >= 50:
            risk_level = "HIGH"
            classification = "PHISHING"
        elif final_risk_score >= 25:
            risk_level = "MEDIUM"
            classification = "SUSPICIOUS"
        else:
            risk_level = "LOW"
            classification = "BENIGN"

        # Overall fusion confidence calculation
        confidences = [ev.get("confidence", 0.8) for ev in evidence_items if ev.get("confidence")]
        overall_confidence = round(sum(confidences) / len(confidences), 2) if confidences else 0.85

        summary = self._generate_summary(final_risk_score, risk_level, classification, breakdown)

        return {
            "risk_score": final_risk_score,
            "risk_level": risk_level,
            "classification": classification,
            "confidence": overall_confidence,
            "summary": summary,
            "score_breakdown": [b for b in breakdown if b["contribution"] > 0]
        }

    def _generate_summary(self, score: float, level: str, classification: str, breakdown: List[Dict[str, Any]]) -> str:
        signals_text = ", ".join([b["signal"].replace("_", " ") for b in breakdown if b["contribution"] > 0])
        if level in ["CRITICAL", "HIGH"]:
            return f"High risk threat detected ({classification}, score {score}/100, level {level}). Primary indicators: {signals_text or 'suspicious patterns'}."
        elif level == "MEDIUM":
            return f"Suspicious activity detected (score {score}/100, level {level}). Caution advised due to: {signals_text or 'uncertain signals'}."
        else:
            return f"No significant phishing or scam indicators detected (score {score}/100, level {level}). Content appears benign."
