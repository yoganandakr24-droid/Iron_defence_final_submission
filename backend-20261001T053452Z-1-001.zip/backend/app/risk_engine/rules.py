from typing import Dict, Any

# Transparent scoring contributions
RULE_CONTRIBUTIONS = {
    "NLP_PHISHING_INTENT": 25.0,
    "NLP_SUSPICIOUS_INTENT": 12.0,
    "MALICIOUS_REPUTATION": 30.0,
    "SUSPICIOUS_REPUTATION": 18.0,
    "SUSPICIOUS_URL_PATTERN": 15.0,
    "CREDENTIAL_REQUEST": 10.0,
    "FINANCIAL_REQUEST": 10.0,
    "IMPERSONATION": 8.0,
    "URGENCY": 5.0,
    "FEAR": 5.0,
    "REWARD": 5.0,
    "SCARCITY": 4.0,
    "QR_CODE_EMBEDDED": 10.0,
}

# Configurable Risk Level Thresholds
DEFAULT_THRESHOLDS = {
    "LOW": (0, 24),
    "MEDIUM": (25, 49),
    "HIGH": (50, 74),
    "CRITICAL": (75, 100)
}
