import re
from typing import Dict, Any, List
from app.utils.text_utils import normalize_text

class SocialEngineeringAnalyzer:
    """
    Transparent regex, keyword, and rule-based social engineering signal analyzer.
    Supports English, Hindi, and Kannada patterns.
    """

    PATTERNS = {
        "urgency": {
            "weight": 0.8,
            "regex": [
                r"\b(urgent|immediately|today only|suspended|deactivated|expire[s]?|within 24 hours|last chance|action required|hurry)\b",
                r"(तुरंत|निलंबित|कार्रवाई आवश्यक|अंतिम अवसर)",
                r"(ತಕ್ಷಣ|ಅಮಾನತು|ಕೊನೆಯ ಅವಕಾಶ)"
            ]
        },
        "fear": {
            "weight": 0.85,
            "regex": [
                r"\b(blocked|suspended|legal action|penalty|arrest|unauthorized|security threat|police|fine)\b",
                r"(ब्लॉक|कानूनी कार्रवाई|जुर्माना|पुलिस)",
                r"(ಬ್ಲಾಕ್|ನ್ಯಾಯಾಲಯ|ದಂಡ)"
            ]
        },
        "authority": {
            "weight": 0.75,
            "regex": [
                r"\b(university|college|administration|dean|principal|head office|bank|rbi|placement cell|official portal)\b",
                r"(विश्वविद्यालय|कॉलेज|प्रशासन|बैंक|आधिकारिक)",
                r"(ವಿಶ್ವವಿದ್ಯಾಲಯ|ಕಾಲೇಜು|ಆಡಳಿತ|ಬ್ಯಾಂಕ್)"
            ]
        },
        "reward": {
            "weight": 0.7,
            "regex": [
                r"\b(congratulations|selected|scholarship|approved|won|stipend|grant|prize|cashback|free)\b",
                r"(बधाई|छात्रवृत्ति|स्वीकृत|जीता|पुरस्कार)",
                r"(ಅಭಿನಂದನೆಗಳು|ಶಿಷ್ಯವೇತನ|ಆಯ್ಕೆಯಾಗಿದ್ದೀರಿ)"
            ]
        },
        "scarcity": {
            "weight": 0.75,
            "regex": [
                r"\b(limited seats|only \d+ left|exclusive|expires soon|first come)\b",
                r"(सीमित सीटें|केवल \d+ शेष)",
                r"(ಸೀಮಿತ ಸೀಟುಗಳು)"
            ]
        },
        "impersonation": {
            "weight": 0.85,
            "regex": [
                r"\b(verify your student account|university desk|bank support desk|customer care|helpdesk|admin)\b",
                r"(छात्र खाता|बैंक सहायता)",
                r"(ವಿದ್ಯಾರ್ಥಿ ಖಾತೆ|ಬ್ಯಾಂಕ್ ಸಹಾಯ)"
            ]
        },
        "credential_request": {
            "weight": 0.95,
            "regex": [
                r"\b(password|verify your password|login|credentials|enter password|reset password|passcode|secret key)\b",
                r"(पासवर्ड|लॉगिन|पासवर्ड दर्ज)",
                r"(ಪಾಸ್ವರ್ಡ್|ಲಾಗಿನ್)"
            ]
        },
        "financial_request": {
            "weight": 0.9,
            "regex": [
                r"\b(pay|payment|bank details|otp|upi|credit card|fee|transfer|₹|rs|deposit)\b",
                r"(भुगतान|बैंक खाता|ओटीपी|पैसे|फीस|रुपये)",
                r"(ಪಾವತಿ|ಬ್ಯಾಂಕ್ ವಿವರ|ಒಟಿಪಿ|ಹಣ|ಶುಲ್ಕ)"
            ]
        },
        "call_to_action": {
            "weight": 0.6,
            "regex": [
                r"\b(click here|link|verify now|claim now|download|visit|open link|confirm now)\b",
                r"(यहाँ क्लिक करें|सत्यापित करें|दावा करें)",
                r"(ಇಲ್ಲಿ ಕ್ಲಿಕ್ ಮಾಡಿ|ಪರಿಶೀಲಿಸಿ)"
            ]
        },
        "suspicious_attachment": {
            "weight": 0.8,
            "regex": [
                r"\b(attached|attachment|\.exe|\.zip|\.scr|\.bat|\.pdf|\.docm)\b"
            ]
        },
        "suspicious_link": {
            "weight": 0.7,
            "regex": [
                r"https?:\/\/[^\s]+",
                r"www\.[^\s]+"
            ]
        }
    }

    def analyze(self, text: str) -> Dict[str, Dict[str, Any]]:
        text_norm = normalize_text(text)
        results = {}

        for signal_name, config in self.PATTERNS.items():
            detected = False
            matches = []
            for pattern in config["regex"]:
                found = re.findall(pattern, text_norm, re.IGNORECASE)
                if found:
                    detected = True
                    # Flatten matches if tuples returned from re.findall
                    for f in found:
                        if isinstance(f, tuple):
                            matches.extend([item for item in f if item])
                        else:
                            matches.append(f)

            results[signal_name] = {
                "detected": detected,
                "score": config["weight"] if detected else 0.0,
                "matches": list(dict.fromkeys(matches)) if detected else []
            }

        return results
