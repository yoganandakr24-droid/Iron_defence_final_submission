import io
import cv2
import numpy as np
from PIL import Image
from typing import Dict, Any, Tuple
from app.core.logging import logger
from app.utils.url_utils import extract_urls

class QRAnalyzer:
    """
    Decodes QR codes using OpenCV QRCodeDetector with fallback to PyZBar if installed.
    """

    def decode_qr(self, image_bytes: bytes) -> Dict[str, Any]:
        try:
            # Load image with PIL then convert to numpy array for OpenCV
            pil_img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
            img_np = np.array(pil_img)
            # Convert RGB to BGR for OpenCV
            img_bgr = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)

            decoded_text = ""
            qr_detected = False

            # Try OpenCV QRCodeDetector first
            detector = cv2.QRCodeDetector()
            data, bbox, _ = detector.detectAndDecode(img_bgr)
            if data:
                decoded_text = data
                qr_detected = True

            # Try OpenCV QRCodeDetectorMulti if single detector failed
            if not qr_detected and hasattr(detector, 'detectAndDecodeMulti'):
                retval, decoded_info, _, _ = detector.detectAndDecodeMulti(img_bgr)
                if retval and decoded_info:
                    for item in decoded_info:
                        if item:
                            decoded_text = item
                            qr_detected = True
                            break

            # Fallback to PyZBar if available
            if not qr_detected:
                try:
                    from pyzbar.pyzbar import decode as pyzbar_decode
                    barcodes = pyzbar_decode(pil_img)
                    if barcodes:
                        decoded_text = barcodes[0].data.decode('utf-8')
                        qr_detected = True
                except Exception as zbar_err:
                    logger.debug(f"pyzbar fallback not available or failed: {zbar_err}")

            if not qr_detected or not decoded_text:
                return {
                    "qr_detected": False,
                    "decoded_content": None,
                    "content_type": None,
                    "message": "No QR code detected in the uploaded image."
                }

            # Determine content type (URL vs text)
            urls = extract_urls(decoded_text)
            content_type = "url" if (urls or decoded_text.startswith(("http://", "https://"))) else "text"

            return {
                "qr_detected": True,
                "decoded_content": decoded_text,
                "content_type": content_type,
                "extracted_urls": urls
            }

        except Exception as e:
            logger.error(f"QR analysis failed: {e}")
            return {
                "qr_detected": False,
                "decoded_content": None,
                "content_type": None,
                "error": str(e)
            }
