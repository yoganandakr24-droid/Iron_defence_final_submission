import io
from PIL import Image
from typing import Dict, Any
from app.core.logging import logger

class OCRAnalyzer:
    """
    Extracts text from images using pytesseract (with Pillow preprocessing).
    Gracefully handles cases where Tesseract binary or pytesseract is unavailable.
    """

    def extract_text(self, image_bytes: bytes) -> Dict[str, Any]:
        try:
            pil_img = Image.open(io.BytesIO(image_bytes))
            
            # Try pytesseract
            try:
                import pytesseract
                # Perform OCR
                extracted_text = pytesseract.image_to_string(pil_img)
                # Try getting data for confidence
                confidence = None
                try:
                    data = pytesseract.image_to_data(pil_img, output_type=pytesseract.Output.DICT)
                    confs = [int(c) for c in data.get('conf', []) if isinstance(c, (int, str)) and str(c).isdigit() and int(c) >= 0]
                    if confs:
                        confidence = round(sum(confs) / len(confs) / 100.0, 2)
                except Exception:
                    confidence = 0.85

                text_clean = extracted_text.strip()
                return {
                    "ocr_available": True,
                    "extracted_text": text_clean,
                    "confidence": confidence if confidence is not None else 0.85,
                    "has_text": len(text_clean) > 0
                }

            except (ImportError, Exception) as tesseract_err:
                logger.warning(f"Tesseract OCR unavailable or failed: {tesseract_err}")
                return {
                    "ocr_available": False,
                    "extracted_text": "",
                    "confidence": 0.0,
                    "has_text": False,
                    "message": "OCR engine (Tesseract) is unavailable or not configured. Returning empty text."
                }

        except Exception as e:
            logger.error(f"Failed to process image for OCR: {e}")
            return {
                "ocr_available": False,
                "extracted_text": "",
                "confidence": 0.0,
                "has_text": False,
                "error": str(e)
            }
