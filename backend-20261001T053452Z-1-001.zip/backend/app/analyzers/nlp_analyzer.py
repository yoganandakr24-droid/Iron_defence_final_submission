import os
import json
import httpx
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from app.core.config import settings
from app.core.logging import logger
from app.utils.text_utils import match_multilingual_signals, normalize_text

class LLMStructuredOutput(BaseModel):
    classification: str = Field(..., description="BENIGN | SUSPICIOUS | PHISHING")
    social_engineering: Dict[str, bool] = Field(default_factory=dict)
    attacker_objective: str = Field("UNKNOWN", description="CREDENTIAL_THEFT | FINANCIAL_FRAUD | INFORMATION_THEFT | MALWARE_DELIVERY | ACCOUNT_TAKEOVER | UNKNOWN")
    semantic_risk: str = Field("LOW", description="LOW | MEDIUM | HIGH")
    reasoning_summary: str = Field("", description="Short explanation based only on input.")

class NLPResult(BaseModel):
    classification: str
    phishing_probability: Optional[float] = None
    heuristic_score: Optional[float] = None
    model: str
    signals: list = Field(default_factory=list)
    score_type: str  # "model_probability" or "heuristic"
    llm_output: Optional[Dict[str, Any]] = None

class MockNLPProvider:
    def __init__(self):
        self.model_name = "iron-defense-heuristic-v1"

    def analyze(self, text: str) -> NLPResult:
        text_norm = normalize_text(text)
        text_lower = text_norm.lower()

        signals = []
        heuristic_score = 0.0

        urgency = match_multilingual_signals(text_norm, "urgency")
        if urgency["detected"]:
            signals.append("urgency_language")
            heuristic_score += 25.0

        credential = match_multilingual_signals(text_norm, "credential_request")
        if credential["detected"]:
            signals.append("credential_harvesting_language")
            heuristic_score += 35.0

        financial = match_multilingual_signals(text_norm, "financial_request")
        if financial["detected"]:
            signals.append("financial_fraud_language")
            heuristic_score += 30.0

        reward = match_multilingual_signals(text_norm, "reward")
        if reward["detected"]:
            signals.append("reward_lure_language")
            heuristic_score += 20.0

        if "http://" in text_lower or "https://" in text_lower or ".com" in text_lower or ".example" in text_lower:
            signals.append("contains_url")
            heuristic_score += 15.0

        score_final = min(100.0, heuristic_score)

        if score_final >= 65:
            classification = "PHISHING"
        elif score_final >= 35:
            classification = "SUSPICIOUS"
        else:
            classification = "BENIGN"

        return NLPResult(
            classification=classification,
            phishing_probability=None,
            heuristic_score=round(score_final, 2),
            model=self.model_name,
            signals=signals,
            score_type="heuristic"
        )

class OllamaProvider:
    def __init__(self, base_url: str = None, model_name: str = None):
        self.base_url = (base_url or settings.OLLAMA_BASE_URL).rstrip("/")
        self.model_name = model_name or settings.OLLAMA_MODEL

    async def analyze(self, text: str) -> NLPResult:
        system_prompt = (
            "You are a cybersecurity analyzer. Analyze the provided message and return ONLY valid JSON matching this schema:\n"
            "{\n"
            '  "classification": "BENIGN | SUSPICIOUS | PHISHING",\n'
            '  "social_engineering": {\n'
            '    "urgency": false,\n'
            '    "fear": false,\n'
            '    "authority_impersonation": false,\n'
            '    "reward": false,\n'
            '    "scarcity": false,\n'
            '    "credential_request": false,\n'
            '    "financial_request": false,\n'
            '    "impersonation": false\n'
            "  },\n"
            '  "attacker_objective": "CREDENTIAL_THEFT | FINANCIAL_FRAUD | INFORMATION_THEFT | MALWARE_DELIVERY | ACCOUNT_TAKEOVER | UNKNOWN",\n'
            '  "semantic_risk": "LOW | MEDIUM | HIGH",\n'
            '  "reasoning_summary": "Short explanation (2-3 sentences max)."\n'
            "}\n"
            "Do not include markdown or extra text outside JSON."
        )

        payload = {
            "model": self.model_name,
            "prompt": f"{system_prompt}\n\nInput message to analyze:\n\"\"\"{text}\"\"\"",
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.1}
        }

        import time
        from fastapi import HTTPException, status
        start_time = time.time()

        try:
            async with httpx.AsyncClient(timeout=180.0) as client:
                resp = await client.post(f"{self.base_url}/api/generate", json=payload)
                latency_ms = round((time.time() - start_time) * 1000, 2)
                
                if resp.status_code == 200:
                    logger.info(f"Ollama call successful | Model: {self.model_name} | Latency: {latency_ms}ms")
                    raw_response = resp.json().get("response", "")
                    json_str = raw_response.strip()
                    if json_str.startswith("```json"):
                        json_str = json_str[7:]
                    if json_str.startswith("```"):
                        json_str = json_str[3:]
                    if json_str.endswith("```"):
                        json_str = json_str[:-3]
                    json_str = json_str.strip()

                    data = json.loads(json_str)
                    parsed = LLMStructuredOutput(**data)

                    signals = [k for k, v in parsed.social_engineering.items() if v]

                    return NLPResult(
                        classification=parsed.classification.upper(),
                        phishing_probability=None,
                        heuristic_score=75.0 if parsed.semantic_risk == "HIGH" else (45.0 if parsed.semantic_risk == "MEDIUM" else 15.0),
                        model=f"ollama/{self.model_name}",
                        signals=signals,
                        score_type="heuristic",
                        llm_output=parsed.model_dump()
                    )
                else:
                    err_msg = f"Ollama HTTP error {resp.status_code}: {resp.text}"
                    logger.error(f"Ollama call failed | Model: {self.model_name} | Latency: {latency_ms}ms | Error: {err_msg}")
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail={"error": {"code": "OLLAMA_ERROR", "message": err_msg}}
                    )
        except Exception as e:
            latency_ms = round((time.time() - start_time) * 1000, 2)
            logger.error(f"Ollama call failed | Model: {self.model_name} | Latency: {latency_ms}ms | Error: {str(e)}")
            if isinstance(e, HTTPException):
                raise e
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={"error": {"code": "OLLAMA_UNREACHABLE", "message": f"Ollama service at {self.base_url} is unreachable: {str(e)}"}}
            )

class DeBERTaProvider:
    def __init__(self, model_path: str):
        self.model_path = model_path
        self.tokenizer = None
        self.model = None
        self._load_model()

    def _load_model(self):
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            import torch
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            self.model = AutoModelForSequenceClassification.from_pretrained(self.model_path)
            self.model.to(torch.float32)
            self.model.eval()
            logger.info(f"Loaded DeBERTa model from {self.model_path}")
        except Exception as e:
            logger.error(f"Failed to load DeBERTa model: {e}")
            self.model = None

    def analyze(self, text: str) -> Optional[NLPResult]:
        if not self.model or not self.tokenizer:
            return None
        try:
            import torch
            inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
            with torch.no_grad():
                outputs = self.model(**inputs)
                probs = torch.softmax(outputs.logits.float(), dim=-1).squeeze().tolist()

            phishing_prob = probs[1] if isinstance(probs, list) and len(probs) > 1 else 0.5
            classification = "PHISHING" if phishing_prob > 0.5 else "BENIGN"

            return NLPResult(
                classification=classification,
                phishing_probability=round(phishing_prob, 4),
                heuristic_score=None,
                model=f"deberta:{os.path.basename(self.model_path)}",
                signals=["deberta_sequence_classification"],
                score_type="model_probability"
            )
        except Exception as e:
            logger.error(f"DeBERTa inference failed: {e}")
            return None

class NLPAnalyzer:
    def __init__(self):
        self.deberta_provider = None
        if settings.DEBERTA_MODEL_PATH and os.path.exists(settings.DEBERTA_MODEL_PATH):
            self.deberta_provider = DeBERTaProvider(settings.DEBERTA_MODEL_PATH)
        
        self.ollama_provider = OllamaProvider()

    async def analyze(self, text: str) -> NLPResult:
        # Priority 1: DeBERTa if model exists
        if self.deberta_provider:
            res = self.deberta_provider.analyze(text)
            if res:
                return res

        # Ollama LLM provider (raises error if unreachable, no mock fallback)
        return await self.ollama_provider.analyze(text)
