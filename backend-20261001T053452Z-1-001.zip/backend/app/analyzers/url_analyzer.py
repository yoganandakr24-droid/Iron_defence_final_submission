from typing import List, Dict, Any
from app.utils.url_utils import extract_urls, parse_url_details

class URLAnalyzer:
    """
    Analyzes URLs extracted from text or input strings and calculates heuristic risk scores.
    """

    def analyze_urls(self, text_or_url: str) -> Dict[str, Any]:
        urls = extract_urls(text_or_url)
        if not urls and (text_or_url.startswith("http://") or text_or_url.startswith("https://") or "." in text_or_url):
            urls = [text_or_url]

        analyzed_results = []
        overall_max_risk = 0.0

        for url in urls:
            details = parse_url_details(url)
            if not details["valid"]:
                continue

            patterns = []
            risk_score = 0.0

            # 1. IP address instead of domain
            if details["is_ip_address"]:
                patterns.append("IP address host used instead of registered domain")
                risk_score += 35.0

            # 2. Shortened URL
            if details["is_shortened"]:
                patterns.append("URL shortener service obfuscation")
                risk_score += 25.0

            # 3. Punycode IDN Homograph
            if details["is_punycode"]:
                patterns.append("Punycode IDN homograph encoding detected")
                risk_score += 30.0

            # 4. @ Symbol in URL (userinfo spoofing)
            if details["has_at_symbol"]:
                patterns.append("Userinfo '@' credential-stuffing/redirection symbol in URL")
                risk_score += 30.0

            # 5. Suspicious TLD
            if details["is_suspicious_tld"]:
                patterns.append(f"High-risk/low-reputation TLD (.{details['tld']})")
                risk_score += 20.0

            # 6. Excessive subdomains
            if details["number_of_subdomains"] >= 3:
                patterns.append(f"Excessive subdomains count ({details['number_of_subdomains']})")
                risk_score += 15.0

            # 7. Hex or URL encoding
            if details["has_hex_encoding"]:
                patterns.append("Hexadecimal or excessive URL encoding in path/query")
                risk_score += 10.0

            # 8. Suspicious Port
            if details["has_suspicious_port"]:
                patterns.append("Non-standard web port requested")
                risk_score += 15.0

            # 9. Suspicious keywords in URL
            if details["matched_suspicious_keywords"]:
                kws = ", ".join(details["matched_suspicious_keywords"])
                patterns.append(f"Suspicious sensitive keywords in URL ({kws})")
                risk_score += min(30.0, len(details["matched_suspicious_keywords"]) * 10.0)

            # 10. Not HTTPS (HTTP plain text)
            if not details["is_https"]:
                patterns.append("Unencrypted HTTP protocol (lack of SSL/TLS)")
                risk_score += 15.0

            # Cap risk score at 100
            final_url_risk = min(100.0, round(risk_score, 2))
            if final_url_risk > overall_max_risk:
                overall_max_risk = final_url_risk

            analyzed_results.append({
                "url": details["url"],
                "domain": details["registered_domain"] or details["domain"],
                "hostname": details["hostname"],
                "is_https": details["is_https"],
                "is_ip_address": details["is_ip_address"],
                "is_punycode": details["is_punycode"],
                "is_shortened": details["is_shortened"],
                "suspicious_patterns": patterns,
                "risk_score": final_url_risk,
                "details": details
            })

        primary = analyzed_results[0] if analyzed_results else None

        return {
            "urls_found": [r["url"] for r in analyzed_results],
            "count": len(analyzed_results),
            "max_risk_score": overall_max_risk,
            "primary_url": primary,
            "all_urls": analyzed_results
        }
