from typing import List, Dict, Any
from app.utils.url_utils import extract_urls, parse_url_details

def extract_iocs(text: str) -> Dict[str, List[Any]]:
    urls = extract_urls(text)
    domains = []
    ips = []

    for u in urls:
        details = parse_url_details(u)
        if details["is_ip_address"]:
            ips.append(details["hostname"])
        elif details["registered_domain"]:
            domains.append(details["registered_domain"])

    return {
        "urls": urls,
        "domains": list(dict.fromkeys(domains)),
        "ips": list(dict.fromkeys(ips))
    }
