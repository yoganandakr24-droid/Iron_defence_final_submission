import json
import os
import httpx
from typing import Dict, Any, Optional
from app.core.config import settings
from app.core.logging import logger

DEMO_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "demo_threat_intel.json")

class ThreatIntelProvider:
    def __init__(self):
        self.provider_name = settings.THREAT_INTEL_PROVIDER
        self.api_key = settings.THREAT_INTEL_API_KEY
        self.demo_data = self._load_demo_data()

    def _load_demo_data(self) -> Dict[str, Any]:
        try:
            abs_path = os.path.abspath(DEMO_DATA_PATH)
            if os.path.exists(abs_path):
                with open(abs_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load demo threat intel data: {e}")
        return {"domains": {}}

    async def lookup_domain(self, domain_or_url: str) -> Dict[str, Any]:
        if not domain_or_url:
            return {
                "available": False,
                "provider": self.provider_name,
                "reputation": "unknown",
                "message": "No domain provided"
            }

        clean_domain = domain_or_url.lower().strip()
        if "://" in clean_domain:
            clean_domain = clean_domain.split("://")[1].split("/")[0].split(":")[0]

        # Check VirusTotal / URLScan if configured and API key present
        if self.provider_name == "virustotal" and self.api_key:
            res = await self._query_virustotal(clean_domain)
            if res:
                return res

        # Fallback to Demo / Mock Threat Intel
        demo_domains = self.demo_data.get("domains", {})
        if clean_domain in demo_domains:
            entry = demo_domains[clean_domain]
            return {
                "available": True,
                "provider": "mock",
                "reputation": entry.get("reputation", "unknown"),
                "category": entry.get("category", "unknown"),
                "threat_type": entry.get("threat_type", "unknown"),
                "score": entry.get("score", 0),
                "source": "DEMO DATA",
                "tags": entry.get("tags", []),
                "message": f"Demonstration Threat Intel match for domain '{clean_domain}'"
            }

        # Subdomain / domain check in demo data
        for d, entry in demo_domains.items():
            if clean_domain.endswith("." + d) or d.endswith("." + clean_domain):
                return {
                    "available": True,
                    "provider": "mock",
                    "reputation": entry.get("reputation", "unknown"),
                    "category": entry.get("category", "unknown"),
                    "threat_type": entry.get("threat_type", "unknown"),
                    "score": entry.get("score", 0),
                    "source": "DEMO DATA",
                    "tags": entry.get("tags", []),
                    "message": f"Demonstration Threat Intel match for base domain '{d}'"
                }

        # If API unavailable / key missing / domain unknown
        return {
            "available": False,
            "provider": self.provider_name if self.api_key else "mock",
            "reputation": "unknown",
            "score": 0,
            "message": "External threat intelligence unavailable or domain unknown in demo database"
        }

    async def _query_virustotal(self, domain: str) -> Optional[Dict[str, Any]]:
        headers = {"x-apikey": self.api_key}
        url = f"https://www.virustotal.com/api/v3/domains/{domain}"
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get(url, headers=headers)
                if resp.status_code == 200:
                    stats = resp.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
                    malicious = stats.get("malicious", 0)
                    suspicious = stats.get("suspicious", 0)
                    if malicious > 0:
                        reputation = "malicious"
                    elif suspicious > 0:
                        reputation = "suspicious"
                    else:
                        reputation = "clean"
                    return {
                        "available": True,
                        "provider": "virustotal",
                        "reputation": reputation,
                        "malicious_count": malicious,
                        "suspicious_count": suspicious,
                        "score": min(100, (malicious * 20) + (suspicious * 10)),
                        "source": "VirusTotal API"
                    }
        except Exception as e:
            logger.warning(f"VirusTotal query failed: {e}")
        return None
