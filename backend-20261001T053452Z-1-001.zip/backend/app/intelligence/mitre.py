import json
import os
from typing import List, Dict, Any
from app.core.logging import logger

MITRE_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "mitre_mapping.json")

class MITREMapper:
    """
    Maps detected evidence signals to relevant MITRE ATT&CK techniques.
    Focuses on DETECTED BEHAVIOR, avoiding false actor attribution.
    """

    def __init__(self):
        self.mappings = self._load_mappings()

    def _load_mappings(self) -> Dict[str, Any]:
        try:
            abs_path = os.path.abspath(MITRE_DATA_PATH)
            if os.path.exists(abs_path):
                with open(abs_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load MITRE mapping data: {e}")
        return {}

    def map_evidence(self, evidence_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        mapped_techniques = []
        seen_ids = set()

        for item in evidence_items:
            signal = item.get("signal")
            category = item.get("category")

            key = None
            if signal in self.mappings:
                key = signal
            elif category == "QR" and "QR_CODE" in self.mappings:
                key = "QR_CODE"
            elif category == "URL" and "SUSPICIOUS_LINK" in self.mappings:
                key = "SUSPICIOUS_LINK"

            if key and key in self.mappings:
                data = self.mappings[key]
                tech_id = data["technique_id"]
                if tech_id not in seen_ids:
                    seen_ids.add(tech_id)
                    mapped_techniques.append({
                        "technique_id": tech_id,
                        "technique": data["technique"],
                        "reason": data["reason"],
                        "attribution_disclaimer": "Behavioral mapping based on observed TTPs; does not constitute threat actor attribution."
                    })

        return mapped_techniques
