from typing import Dict, Any
from app.intelligence.reputation import ThreatIntelProvider

class ThreatIntelService:
    def __init__(self):
        self.provider = ThreatIntelProvider()

    async def check_domain(self, domain_or_url: str) -> Dict[str, Any]:
        return await self.provider.lookup_domain(domain_or_url)
