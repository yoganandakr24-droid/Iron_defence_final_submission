from typing import Dict, Any
from app.analyzers.qr_analyzer import QRAnalyzer

class QRService:
    def __init__(self):
        self.analyzer = QRAnalyzer()

    def process_qr_image(self, image_bytes: bytes) -> Dict[str, Any]:
        return self.analyzer.decode_qr(image_bytes)
