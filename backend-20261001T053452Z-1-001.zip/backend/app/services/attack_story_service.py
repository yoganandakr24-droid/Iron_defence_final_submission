from typing import Dict, Any, List

class AttackStoryService:
    """
    Generates structured attack stories, objective classification,
    and recommended safe actions based on evidence.
    """

    def determine_attacker_objective(self, evidence_items: List[Dict[str, Any]], se_results: Dict[str, Any]) -> Dict[str, Any]:
        signals = [ev.get("signal") for ev in evidence_items]
        
        if "CREDENTIAL_REQUEST" in signals or (se_results and se_results.get("credential_request", {}).get("detected")):
            return {
                "objective": "CREDENTIAL_THEFT",
                "confidence": 0.90,
                "score_type": "heuristic",
                "evidence": ["Detected explicit credential/password verification request"]
            }
        
        if "FINANCIAL_REQUEST" in signals or (se_results and se_results.get("financial_request", {}).get("detected")):
            return {
                "objective": "FINANCIAL_FRAUD",
                "confidence": 0.88,
                "score_type": "heuristic",
                "evidence": ["Detected payment, fee, or financial details request"]
            }

        if se_results and se_results.get("impersonation", {}).get("detected"):
            return {
                "objective": "ACCOUNT_TAKEOVER",
                "confidence": 0.82,
                "score_type": "heuristic",
                "evidence": ["Authority impersonation attempting account access"]
            }

        if se_results and se_results.get("suspicious_attachment", {}).get("detected"):
            return {
                "objective": "MALWARE_DELIVERY",
                "confidence": 0.85,
                "score_type": "heuristic",
                "evidence": ["Suspicious attachment detected"]
            }

        return {
            "objective": "UNKNOWN",
            "confidence": 0.50,
            "score_type": "heuristic",
            "evidence": ["Insufficient evidence to confirm specific objective"]
        }

    def generate_attack_story(
        self,
        source: str,
        objective_info: Dict[str, Any],
        se_results: Dict[str, Any],
        url_results: Dict[str, Any],
        risk_level: str
    ) -> Dict[str, str]:
        
        obj = objective_info.get("objective", "UNKNOWN")
        source_name = (source or "sms").upper()

        # Entry vector
        entry_vector = f"{source_name} communication received targeting student/user."

        # Social engineering summary
        se_traits = []
        if se_results:
            for k, v in se_results.items():
                if v.get("detected"):
                    se_traits.append(k.replace("_", " "))
        social_engineering = f"Attacker utilizes {', '.join(se_traits) if se_traits else 'deceptive messaging'} to induce victim compliance."

        # User action
        if url_results and url_results.get("urls_found"):
            user_action = f"Victim is instructed to click link ({url_results['urls_found'][0]}) and follow landing page instructions."
        else:
            user_action = "Victim is prompted to reply with sensitive details or execute requested payment."

        # Attacker objective
        attacker_objective = f"Targeting {obj.replace('_', ' ').title()}."

        # Potential impact
        if obj == "CREDENTIAL_THEFT":
            potential_impact = "Compromise of university account credentials, identity theft, and unauthorized portal access."
        elif obj == "FINANCIAL_FRAUD":
            potential_impact = "Direct monetary loss through fraudulent UPI/bank transfers or fee scams."
        elif obj == "MALWARE_DELIVERY":
            potential_impact = "Device infection, ransomware deployment, or unauthorized local data extraction."
        else:
            potential_impact = "Potential breach of student privacy or exposure to follow-on phishing attacks."

        return {
            "entry_vector": entry_vector,
            "social_engineering": social_engineering,
            "user_action": user_action,
            "attacker_objective": attacker_objective,
            "potential_impact": potential_impact
        }

    def generate_safe_actions(self, risk_level: str) -> List[str]:
        if risk_level == "CRITICAL":
            return [
                "Do NOT interact with the message, link, or QR code.",
                "Do NOT provide OTP, password, banking, or personal details under any circumstances.",
                "Manually visit the official university or banking website in a clean browser window.",
                "Report this incident immediately to the IT Security / Administrative Helpdesk.",
                "If credentials were already entered on the suspicious page, immediately initiate account recovery on the official portal and change your password."
            ]
        elif risk_level == "HIGH":
            return [
                "Do NOT click on any links or download attached files.",
                "Do NOT provide credentials or financial details.",
                "Verify the claim independently using official phone numbers or websites.",
                "Report the message as spam/phishing to your service provider or department."
            ]
        elif risk_level == "MEDIUM":
            return [
                "Do not click unknown or unverified links.",
                "Verify sender authenticity through official communication channels before responding.",
                "Check for spelling errors or unexpected urgency in the message."
            ]
        else:  # LOW
            return [
                "Verify sender identity if the message was unexpected.",
                "Continue normally while adhering to standard cybersecurity hygiene."
            ]
