from typing import Dict, Any, Optional
from app.analyzers.nlp_analyzer import OllamaProvider, MockNLPProvider, LLMStructuredOutput
from app.core.config import settings
from app.core.logging import logger

class LLMService:
    def __init__(self):
        self.ollama_provider = OllamaProvider()

    async def analyze_message(self, text: str) -> Dict[str, Any]:
        res = await self.ollama_provider.analyze(text)
        if res and res.llm_output:
            return res.llm_output
        raise Exception("Ollama did not return structured output")
