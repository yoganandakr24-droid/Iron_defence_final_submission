import uuid
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from app.services.message_service import MessageService
from app.services.url_service import URLService
from app.services.qr_service import QRService
from app.services.ocr_service import OCRService
from app.services.threat_intel_service import ThreatIntelService
from app.services.attack_story_service import AttackStoryService
from app.risk_engine.evidence_fusion import EvidenceFusionEngine
from app.risk_engine.risk_calculator import RiskEngine
from app.intelligence.mitre import MITREMapper
from app.models.analysis import AnalysisRecord
from app.utils.url_utils import extract_urls
from app.core.logging import logger

class AnalysisService:
    def __init__(self):
        self.message_service = MessageService()
        self.url_service = URLService()
        self.qr_service = QRService()
        self.ocr_service = OCRService()
        self.threat_intel_service = ThreatIntelService()
        self.attack_story_service = AttackStoryService()
        self.fusion_engine = EvidenceFusionEngine()
        self.risk_engine = RiskEngine()
        self.mitre_mapper = MITREMapper()

    async def run_unified_analysis(
        self,
        db: Session,
        text: Optional[str] = None,
        url: Optional[str] = None,
        image_bytes: Optional[bytes] = None,
        source: Optional[str] = "manual",
        input_type: Optional[str] = "text"
    ) -> Dict[str, Any]:

        start_time = time.time()
        analysis_id = str(uuid.uuid4())
        created_at = datetime.now(timezone.utc).isoformat()

        extracted_text = text or ""
        qr_result = {}
        ocr_result = {}

        # 1. OCR / Image preprocessing if image bytes provided
        if image_bytes:
            # Check QR first
            qr_result = self.qr_service.process_qr_image(image_bytes)
            if qr_result.get("qr_detected") and qr_result.get("decoded_content"):
                qr_content = qr_result["decoded_content"]
                if not extracted_text:
                    extracted_text = qr_content
                else:
                    extracted_text += f"\n[QR Content]: {qr_content}"

            # Check OCR
            ocr_result = self.ocr_service.process_image(image_bytes)
            if ocr_result.get("has_text"):
                ocr_text = ocr_result.get("extracted_text", "")
                if not extracted_text:
                    extracted_text = ocr_text
                else:
                    extracted_text += f"\n[OCR Text]: {ocr_text}"

        # 2. Extract URLs from explicit URL param or text
        all_text_content = f"{extracted_text} {url or ''}".strip()
        extracted_urls = extract_urls(all_text_content)
        if url and url not in extracted_urls:
            extracted_urls.insert(0, url)

        # 3. Execute Analyzers
        # a) Message / NLP / SE Analysis
        msg_result = await self.message_service.analyze_message(all_text_content)
        nlp_res = msg_result["nlp"]
        se_res = msg_result["social_engineering"]

        # b) URL Analysis
        url_res = self.url_service.analyze(" ".join(extracted_urls) if extracted_urls else all_text_content)

        # c) Threat Intelligence Lookup
        primary_domain = None
        if url_res and url_res.get("primary_url"):
            primary_domain = url_res["primary_url"].get("domain") or url_res["primary_url"].get("hostname")
        elif extracted_urls:
            primary_domain = extracted_urls[0]

        threat_intel_res = await self.threat_intel_service.check_domain(primary_domain)

        # 4. Evidence Fusion
        fused_evidence = self.fusion_engine.fuse(
            nlp_result=nlp_res,
            se_result=se_res,
            url_result=url_res,
            threat_intel_result=threat_intel_res,
            qr_result=qr_result,
            ocr_result=ocr_result
        )

        # 5. Risk Engine Calculation
        risk_res = self.risk_engine.calculate_risk(fused_evidence)

        # 6. Attacker Objective & MITRE ATT&CK Mapping
        objective_res = self.attack_story_service.determine_attacker_objective(fused_evidence, se_res)
        mitre_res = self.mitre_mapper.map_evidence(fused_evidence)

        # 7. Attack Story Generation
        attack_story_res = self.attack_story_service.generate_attack_story(
            source=source,
            objective_info=objective_res,
            se_results=se_res,
            url_results=url_res,
            risk_level=risk_res["risk_level"]
        )

        # 8. Safe Action Recommendations
        safe_actions_res = self.attack_story_service.generate_safe_actions(risk_res["risk_level"])

        execution_time_ms = round((time.time() - start_time) * 1000, 2)

        processing_meta = {
            "execution_time_ms": execution_time_ms,
            "input_type": input_type,
            "source": source,
            "nlp_model": nlp_res.get("model"),
            "threat_intel_provider": threat_intel_res.get("provider", "mock")
        }

        # Build complete response dict matching output JSON schema
        response_data = {
            "analysis_id": analysis_id,
            "timestamp": created_at,
            "classification": risk_res["classification"],
            "risk_score": risk_res["risk_score"],
            "risk_level": risk_res["risk_level"],
            "confidence": risk_res["confidence"],
            "summary": risk_res["summary"],
            "evidence": fused_evidence,
            "score_breakdown": risk_res["score_breakdown"],
            "social_engineering": se_res,
            "url_analysis": url_res,
            "threat_intelligence": threat_intel_res,
            "attacker_objective": objective_res,
            "mitre_attack": mitre_res,
            "attack_story": attack_story_res,
            "safe_actions": safe_actions_res,
            "processing": processing_meta
        }

        # 9. Persist Record to SQLite
        try:
            record = AnalysisRecord(
                analysis_id=analysis_id,
                source=source,
                input_type=input_type,
                original_text=all_text_content,
                urls=extracted_urls,
                classification=risk_res["classification"],
                risk_score=risk_res["risk_score"],
                risk_level=risk_res["risk_level"],
                confidence=risk_res["confidence"],
                attacker_objective=objective_res,
                attack_story=attack_story_res,
                evidence=fused_evidence,
                mitre_mapping=mitre_res,
                safe_actions=safe_actions_res,
                full_response=response_data
            )
            db.add(record)
            db.commit()
            db.refresh(record)
        except Exception as db_err:
            logger.error(f"Failed to persist analysis record to database: {db_err}")
            db.rollback()

        return response_data
