from typing import Dict, Any
from app.analyzers.ocr_analyzer import OCRAnalyzer

class OCRService:
    def __init__(self):
        self.analyzer = OCRAnalyzer()

    def process_image(self, image_bytes: bytes) -> Dict[str, Any]:
        return self.analyzer.extract_text(image_bytes)
