from typing import Dict, Any
from app.analyzers.url_analyzer import URLAnalyzer

class URLService:
    def __init__(self):
        self.analyzer = URLAnalyzer()

    def analyze(self, text_or_url: str) -> Dict[str, Any]:
        return self.analyzer.analyze_urls(text_or_url)
