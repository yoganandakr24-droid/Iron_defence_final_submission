from typing import Dict, Any
from app.analyzers.nlp_analyzer import NLPAnalyzer
from app.analyzers.social_engineering import SocialEngineeringAnalyzer

class MessageService:
    def __init__(self):
        self.nlp_analyzer = NLPAnalyzer()
        self.se_analyzer = SocialEngineeringAnalyzer()

    async def analyze_message(self, text: str) -> Dict[str, Any]:
        nlp_res = await self.nlp_analyzer.analyze(text)
        se_res = self.se_analyzer.analyze(text)
        
        return {
            "nlp": nlp_res.model_dump(),
            "social_engineering": se_res
        }
